#!/bin/bash

echo "Digite o primeiro número:"
read num1

echo "Digite o operador (+, -, *, /, %):"
read op

echo "Digite o segundo número:"
read num2

# Verifica operador e calcula
case $op in
  +)
    resultado=$((num1 + num2))
    ;;
  -)
    resultado=$((num1 - num2))
    ;;
  \*)
    resultado=$((num1 * num2))
    ;;
  /)
    if [ "$num2" -eq 0 ]; then
      echo "Erro: divisão por zero"
      exit 1
    fi
    resultado=$((num1 / num2))
    ;;
  %)
    resultado=$((num1 % num2))
    ;;
  *)
    echo "Erro: operador inválido"
    exit 1
    ;;
esac

echo "Resultado: $resultado"
