#! /bin/bash

echo "Insira um numero"
read numero

resultado=$((numero % 2))


if [ $resultado  -eq 0 ]; then
  echo "O $numero é par"
else
   echo "O $numero é impar"

fi
