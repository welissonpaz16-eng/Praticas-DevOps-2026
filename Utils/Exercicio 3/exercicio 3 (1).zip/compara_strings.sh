#!/bin/bash

echo "Insira a primeira palavra"
read palavra1

echo "Insira a segunda palavra"
read palavra2

if [ "$palavra1" = "$palavra2" ]; then
   echo "As palavras são iguais"

else

  echo "As palavras são diferentes"

fi

