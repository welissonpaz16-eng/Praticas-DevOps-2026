#!/bin/bash

echo "Digite a primeira string:"
read str1

echo "Digite a segunda string:"
read str2

# Comparação alfabética
if [[ "$str1" < "$str2" ]]; then
  echo "$str1 vem antes de $str2"
elif [[ "$str1" > "$str2" ]]; then
  echo "$str2 vem antes de $str1"
else
  echo "As duas strings são iguais"
fi
