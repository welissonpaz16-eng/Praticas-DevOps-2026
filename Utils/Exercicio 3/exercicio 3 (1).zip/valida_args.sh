#!/bin/bash

if [ $# -ne 3 ]; then
echo "Erro: insira 3 numeros validos"
echo "Uso: $0 argumento1 argumento2 argumento3"
exit 1

fi

echo "Argumentos informados corretamente"
echo "argumento : $1"
echo "argumento : $2"
echo "argumento : $3"
