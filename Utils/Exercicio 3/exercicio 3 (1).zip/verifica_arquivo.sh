#!/bin/bash

echo "Digite o nome do arquivo ou diretório:"
read nome

# Verificações
if [ -f "$nome" ]; then
  echo "O arquivo existe e é um arquivo regular"
elif [ -d "$nome" ]; then
  echo "É um diretório"
else
  echo "O arquivo ou diretório não existe"
fi
