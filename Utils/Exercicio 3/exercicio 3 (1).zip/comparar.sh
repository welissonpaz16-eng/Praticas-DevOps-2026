#!/bin/bash

echo "insira o primeiro numero"
read numero1

echo "Insira o  segundo numero"
read numero2


if [ $numero1 -gt $numero2 ]; then
  echo " O primeiro numero é maior que o segundo numero"

elif [ $numero1  -lt $numero2 ]; then
  echo " O primeiro numero é menor que o segundo numero"

elif [ $numero1 -eq  $numero2 ]; then
  echo " o primeiro numero é  igual ao segundo numero"

fi
