#!/bin/bash

analisa_log() {
    LOG="/var/log/syslog"
    SAIDA="$HOME/exercicios-shell/erros_$(date +%Y-%m-%d).txt"

   
    if [ ! -f "$LOG" ]; then
        echo "Arquivo de log não encontrado!"
        exit 1
    fi

  
    grep "ERROR" "$LOG" > "$SAIDA"
}

analisa_log