#!/bin/bash

analisa_log() {
    LOG="/var/log/syslog"
    SAIDA="$HOME/exercicios-shell/erros_$(date +%Y-%m-%d).txt"

    # Verifica se o arquivo existe
    if [ ! -f "$LOG" ]; then
        echo "Arquivo de log não encontrado!"
        exit 1
    fi

    # Procura por linhas com ERROR
    grep "ERROR" "$LOG" > "$SAIDA"
}

# Executa a função
analisa_log