crontab -e
0 3 ** 1/home/uelisson/exercicio/questao1.sh