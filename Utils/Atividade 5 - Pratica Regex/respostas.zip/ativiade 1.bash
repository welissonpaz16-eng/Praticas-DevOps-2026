#!/bin/bash


LOG="/caminho/do/seu/log.txt"


TMP="/tmp/ips_temp.txt"

RELATORIO="/caminho/do/relatorio_final.txt"


extrair_ips() {
    grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' "$LOG" > "$TMP"
}


extrair_ips


cat "$TMP" >> "$RELATORIO"


rm "$TMP"