#!/bin/bash

#!/usr/bin/env bash
# ------------------------------------------------------------------------ #
# Script Name:   file_operations.sh
# Description:   Script multifuncional para manipulação de arquivos + logs
# Written by:    Laizean Maciel
# ------------------------------------------------------------------------ #

# ================= FUNÇÕES ================= #

rename_files() {
    read -p "Arquivo atual: " file
    read -p "Novo nome: " newname

    if [ -f "$file" ]; then
        mv "$file" "$newname"
        echo "Arquivo renomeado com sucesso!"
    else
        echo "Arquivo não encontrado!"
    fi
}

compress_files() {
    read -p "Arquivo ou pasta: " file

    if [ -e "$file" ]; then
        tar -czf "$file.tar.gz" "$file"
        echo "Compactado com sucesso!"
    else
        echo "Arquivo não encontrado!"
    fi
}

extract_files() {
    read -p "Arquivo .tar.gz: " file

    if [ -f "$file" ]; then
        tar -xzf "$file"
        echo "Arquivo extraído!"
    else
        echo "Arquivo não encontrado!"
    fi
}

change_permissions() {
    read -p "Arquivo: " file
    read -p "Permissão (ex: 755): " perm

    if [ -e "$file" ]; then
        chmod "$perm" "$file"
        echo "Permissão alterada!"
    else
        echo "Arquivo não encontrado!"
    fi
}

search_files() {
    read -p "Digite o padrão para busca: " pattern
    echo "Resultados encontrados:"
    grep -r "$pattern" .
}

# 🔥 INTEGRAÇÃO COM A ATIVIDADE 2.1
analyze_logs() {
    if [ -f "regex_log_analyzer.sh" ]; then
        echo "Executando análise de logs..."
        bash regex_log_analyzer.sh
    else
        echo "Script regex_log_analyzer.sh não encontrado!"
    fi
}

# ================= MENU ================= #

show_menu() {
    clear
    echo "=========================================="
    echo "     FILE OPERATIONS - DevOps Tools"
    echo "=========================================="
    echo "1. Renomear arquivo"
    echo "2. Compactar arquivo/pasta"
    echo "3. Extrair arquivo (.tar.gz)"
    echo "4. Alterar permissões"
    echo "5. Buscar conteúdo em arquivos"
    echo "6. Analisar logs Apache"
    echo "0. Sair"
    echo ""
    echo -n "Escolha uma opção: "
}

# ================= MAIN ================= #

while true; do
    show_menu
    read option

    case $option in
        1) rename_files ;;
        2) compress_files ;;
        3) extract_files ;;
        4) change_permissions ;;
        5) search_files ;;
        6) analyze_logs ;;
        0) echo "Saindo..."; exit 0 ;;
        *) echo "Opção inválida!" ;;
    esac

    echo ""
    read -p "Pressione Enter para continuar..."
done
